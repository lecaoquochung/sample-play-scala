# FFMPEG

- FFMPEG binary files are produced by [`//browser_patches/ffmpeg`](../../browser_patches/ffmpeg) scripts.
- To get exact source that produced binary, run executable without arguments and look at the version suffix. It'll be something `n4.3.1-playwright-build-1001` - with the `1001` being the [`ffmpeg/BUILD_NUMBER`](../../browser_patches/ffmpeg/BUILD_NUMBER)

